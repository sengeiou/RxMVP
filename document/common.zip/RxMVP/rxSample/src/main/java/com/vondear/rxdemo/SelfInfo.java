package com.vondear.rxdemo;

/**
 * @author Vondear
 * @date 2018/6/14
 */
public class SelfInfo {

    public static final String ALIPAY_APPID = "";

    public static final String ALIPAY_RSA2_PRIVATE = "";

}
