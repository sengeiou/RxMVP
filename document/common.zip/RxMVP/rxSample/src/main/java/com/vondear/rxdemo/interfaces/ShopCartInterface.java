package com.vondear.rxdemo.interfaces;

import android.view.View;

/**
 *
 * @author vondear
 * @date 16-11-13
 */
public interface ShopCartInterface {
    void add(View view, int postion);
    void remove(View view, int postion);
}
