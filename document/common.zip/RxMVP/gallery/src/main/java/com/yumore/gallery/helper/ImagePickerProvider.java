package com.yumore.gallery.helper;

import android.support.v4.content.FileProvider;

public class ImagePickerProvider extends FileProvider {
}
