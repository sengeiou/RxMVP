package com.yumore.frame.callback;

/**
 * @author Nathaniel
 * @date 2019/4/25 - 21:37
 */
public interface OnNetworkListener {
    void onStatusChanged(int connectedType);
}
