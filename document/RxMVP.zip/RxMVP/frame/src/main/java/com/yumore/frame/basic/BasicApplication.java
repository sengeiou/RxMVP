package com.yumore.frame.basic;

import android.app.Application;

/**
 * @author Nathaniel
 * @date 18-5-9-上午11:35
 */
public class BasicApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
