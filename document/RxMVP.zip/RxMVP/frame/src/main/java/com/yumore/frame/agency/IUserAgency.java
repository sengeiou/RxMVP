package com.yumore.frame.agency;

import com.alibaba.android.arouter.facade.template.IProvider;

/**
 * @author Nathaniel
 * @date 19-3-1 - 下午4:49
 */
public interface IUserAgency extends IProvider {
}
