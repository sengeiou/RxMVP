package com.yumore.sample.mvp.contact;

public interface TestContact {
    /**
     * 获取数据
     */
    void getData();
}
